
// opciones del menú en un arreglo
const opciones = {
  1: "Ingresar",
  2: "Modificar",
  3: "Consultar",
  4: "Eliminar",
  5: "Salir"
};

// solicitar selección del usuario
function mostrarMenu() {
  prompt("Seleccione una opción:");
  
  // Recorre las opciones y las muestra
  for (let i = 1; i <= 5; i++) {
    console.log(`${i}. ${opciones[i]}`);
  }
  
  // selección del usuario
  let seleccion = parseInt(prompt("Ingrese el número de opción:"));
  
  // selección del usuario
  return seleccion;
}

// flujo del menú
function menuPrincipal() {
  while (true) {
    // selección del usuario
    let seleccion = mostrarMenu();
    
    // Verifica la selección del usuario
    switch (seleccion) {
      case 1:
        console.log("Has seleccionado la opción Ingresar.");
        // Aquí puedes agregar la lógica para la opción "Ingresar"
        break;
      case 2:
        console.log("Has seleccionado la opción Modificar.");
        // Aquí puedes agregar la lógica para la opción "Modificar"
        break;
      case 3:
        console.log("Has seleccionado la opción Consultar.");
        // Aquí puedes agregar la lógica para la opción "Consultar"
        break;
      case 4:
        console.log("Has seleccionado la opción Eliminar.");
        // Aquí puedes agregar la lógica para la opción "Eliminar"
        break;
      case 5:
        console.log("Has seleccionado la opción Salir. Chau!");
        // Sale del bucle while
        return;
      default:
        console.log("Opción inválida. Por favor, seleccione una opción válida.");
    }
  }
}

// Llama a la función principal para iniciar el menú
menuPrincipal();